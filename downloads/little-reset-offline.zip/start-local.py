"""Optional stable local origin for the offline edition; Python 3 only."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from functools import partial
from urllib.parse import quote
import webbrowser

folder = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(folder))
try:
    server = ThreadingHTTPServer(("127.0.0.1", 8765), handler)
except OSError as error:
    raise SystemExit("Port 8765 is in use. Stop the previous local server and try again.") from error
url = "http://127.0.0.1:8765/" + quote("慢慢来-本地版.html")
print("Local diary: " + url)
print("Keep this window open. Press Ctrl+C to stop.")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
